public class StudentManagement {

    int max = 100;
    Student[] students = new Student[max];

    public static boolean sameGroup(Student s1, Student s2) {
        return s1.getGroup().equals(s2.getGroup());
    }

    public void addStudent(Student newStudent) {
        for (int i = 0; i < max; i++) {
            if (students[i] == null) {
                students[i] = newStudent;
                break;
            }
        }
    }

    public String studentsByGroup() {
        StringBuilder studentsByGroup = new StringBuilder();
        String[] group = new String[max];
        group[0] = students[0].getGroup();
        int k = 1;
        for(int i = 0; i < max; i++) {
            if (students[i] == null) {
                break;
            }
            boolean test = false;
            for (int j = 0; j < k; j++) {
                if (students[i].getGroup().equals(group[j])) {
                    test = true;
                    break;
                }
            }
            if(!test) {
                group[k] = students[i].getGroup();
                k++;
            }
        }
        for(int i = 0; i < k; i++) {
            if (students[i] == null) {
                break;
            }
            studentsByGroup.append(group[i]).append("\n");
            for (int j = 0; j < max; j++) {
                if (students[j] == null) {
                    break;
                } else {
                    if (students[j].getGroup().equals(group[i]))
                        studentsByGroup.append(students[j].getInfo()).append("\n");
                }
            }
        }
        return studentsByGroup.toString();
    }

    public void removeStudent(String id) {
        int x = -1;
        for (int i = 0; i < max; i++) {
            if (students[i].getId().equals(id)) {
                x = i;
                break;
            }
        }
        if (x >= 0) {
            for (int i = x; i < max - 1; i++) {
                students[i] = students[i+1];
            }
            max--;
        }
    }

    public static void main(String[] args) {
        Student sv = new Student();
        sv.setName("Nguyen Van An");
        sv.setId("17020001");
        sv.setGroup("K62CC");
        sv.setEmail("17020001@vnu.edu.vn");
        System.out.println(sv.getInfo());
    }
}
 