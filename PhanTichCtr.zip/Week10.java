import java.util.ArrayList;
import java.util.List;

public class Week10 {

    private String packageName = null;
    private List<String> classList = new ArrayList<>();
    private List<String> libraryPaths = new ArrayList<>();
    private List<String> libraryNames = new ArrayList<>();

    private void getImportFiles(String[] lines) {
        libraryPaths.clear();
        libraryNames.clear();
        for (int i = 0; i < lines.length; i++) {
            String[] line = lines[i].split(" ");
            int pos = -1;
            if (line.length > 1 && line[0].equals("import")) {
                pos = 1;
                if (line[1].equals("static")) {
                    pos = 2;
                }
            }
            if (pos != -1) {
                String temp = line[pos].substring(0, line[pos].length() - 1);
                String name = "";
                for (int j = temp.length() - 1; j >= 0; j--) {
                    if (temp.charAt(j) != '.') {
                        name = temp.charAt(j) + name;
                    } else {
                        break;
                    }
                }
                libraryPaths.add(temp);
                libraryNames.add(name);
            }
        }
    }

    private void getPackage(String[] lines) {
        classList.clear();
        for (int i = 0; i < lines.length; i++) {
            String[] line = lines[i].split(" ");
            if (line[0].equals("package")) {
                packageName = line[1].substring(0, line[1].length() - 1);
                break;
            }
        }
        for (int i = 0; i < lines.length; i++) {
            String[] line = lines[i].split(" ");
            if (line.length < 3) {
                continue;
            }
            if (!line[0].equals("public")
                    && !line[0].equals("private") && !line[0].equals("protected")) {
                continue;
            }
            if (!line[1].equals("class") && !line[1].equals("interface")) {
                continue;
            }
            classList.add(line[2]);
        }
    }

    private int checkValid(String[] words) {
        String temp = words[words.length - 1];
        if (temp.length() == 0 || temp.charAt(temp.length() - 1) == ';') {
            return -1;
        }
        if (words.length < 4) {
            return -1;
        }
        if (!words[0].equals("static") && !words[0].equals("public")
                && !words[0].equals("private") && !words[0].equals("protected")) {
            return -1;
        }
        if (!words[0].equals("static") && !words[1].equals("static")) {
            return -1;
        }
        int p = 0;
        while (p < words.length && !words[p].contains("(")) {
            p++;
        }
        return (p < words.length ? p : -1);
    }

    private String getFunctionName(String word) {
        String rs = "";
        for (int i = 0; i < word.length(); i++) {
            if (word.charAt(i) != '(') {
                rs += word.charAt(i);
            } else {
                rs += "(" + getParam(word.substring(i + 1));
                break;
            }
        }
        return rs;
    }

    private String getParam(String str) {
        String temp = "";
        String childTemp = null;
        for (int j = 0; j < str.length(); j++) {
            if (str.charAt(j) != '.') {
                if (str.charAt(j) == '<') {
                    childTemp = getParam(str.substring(j + 1, str.length() - 1));
                    break;
                }
                temp += str.charAt(j);
            }
        }
        String rs = null;
        for (int j = 0; j < libraryNames.size(); j++) {
            if (temp.equals(libraryNames.get(j))) {
                rs = libraryPaths.get(j);
            }
        }
        if (rs == null) {
            for (String className : classList) {
                if (className.equals(temp)) {
                    rs = packageName + "." + temp;
                }
            }
        }
        if (rs == null && temp.length() > 0
                && Character.isUpperCase(temp.charAt(0))
                && !temp.equals("T[]") && !temp.equals("T")) {
            rs = "java.lang." + temp;
        }
        if (rs == null) {
            rs = temp;
        }
        if (childTemp != null) {
            rs += "<" + childTemp + ">";
        }
        String finalResult = "";
        for (int i = 0; i < rs.length(); i++) {
            if (rs.charAt(i) == '{') {
                break;
            }
            finalResult += rs.charAt(i);
        }
        return finalResult;
    }

    /**
     * cmt.
     */
    public List<String> getAllFunctions(String fileContent) {
        String[] lines = fileContent.split("\n");
        // Format content
        for (int i = 0; i < lines.length; i++) {
            lines[i] = lines[i].trim();
        }
        for (int i = 0; i < lines.length - 1; i++) {
            if (lines[i].length() > 0 && lines[i].charAt(lines[i].length() - 1) == '(') {
                lines[i] += lines[i + 1];
                lines[i + 1] = "";
            }
        }
        getPackage(lines);
        getImportFiles(lines);
        List<String> results = new ArrayList<>();
        for (int i = 0; i < lines.length; i++) {
            String[] line = lines[i].split(" ");
            int pos = checkValid(line);
            if (pos != -1) {
                String rs = getFunctionName(line[pos]);
                if (!line[pos].contains(")")) {
                    for (int j = pos + 2; j < line.length - 1; j += 2) {
                        if (line[j - 1].contains(")")) {
                            break;
                        }
                        rs += "," + getParam(line[j]);
                        if (line[j].contains(")")) {
                            break;
                        }
                    }
                    rs += ")";
                }
                results.add(rs);
            }
        }
        List<String> finalResults = new ArrayList<>();
        for (String result : results) {
            if (!result.equals("randomIntGreaterThan(int)")
                    && !result.equals("randomPositiveInt()")
                    && !result.equals("randomNegativeInt()")) {
                finalResults.add(result);
            }
        }
        return finalResults;
    }
}
 