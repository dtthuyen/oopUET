import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class Week4Test {
    @Test
    public void testMax2Int1(){
        assertEquals(3, Week4.max2Int(1, 3));
    }

    @Test
    public void testMax2Int2(){
        assertEquals(7, Week4.max2Int(7, -3));
    }

    @Test
    public void testMax2Int3(){
        assertEquals(0, Week4.max2Int(-11, 0));
    }

    @Test
    public void testMax2Int4(){
        assertEquals(10, Week4.max2Int(10, 10));
    }

    @Test
    public void testMax2Int5(){
        assertEquals(4, Week4.max2Int(4, 3));
    }

    @Test
    public void testMinArray1(){
        assertEquals(1, Week4.minArray(new int[]{1, 2, 3, 4, 6}));
    }

    @Test
    public void testMinArray2(){
        assertEquals(-9, Week4.minArray(new int[]{87, 2, 32, -9, -6}));
    }

    @Test
    public void testMinArray3(){
        assertEquals(-7, Week4.minArray(new int[]{-7, 7}));
    }

    @Test
    public void testMinArray4(){
        assertEquals(76, Week4.minArray(new int[]{3687, 894, 76, 95}));
    }

    @Test
    public void testMinArray5(){
        assertEquals(1, Week4.minArray(new int[]{1}));
    }

    @Test
    public void testCalculateBMI1(){
        assertEquals("Bình Thường ", Week4.calculateBMI(55, 1.55));
    }

    @Test
    public void testCalculateBMI2(){
        assertEquals("Béo phì", Week4.calculateBMI(80, 1.63));
    }

    @Test
    public void testCalculateBMI3(){
        assertEquals("Thiếu cân", Week4.calculateBMI(49.5, 1.65));
    }

    @Test
    public void testCalculateBMI4(){
        assertEquals("Bình thường", Week4.calculateBMI(65, 1.78));
    }

    @Test
    public void testCalculateBMI5(){
        assertEquals("Bình thường", Week4.calculateBMI(53, 1.69));
    }
}