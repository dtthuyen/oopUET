public class Week4 {

    /**
     * return max of a and b.
     */
    public static int max2Int(int a, int b) {
        return a > b ? a : b;
    }

    /**
     * return min value of array.
     */
    public static int minArray(int[] arr) {
        int min = arr[0];
        for (int i = 0; i < arr.length; i++) {
            min = arr[i] < min ? arr[i] : min;
        }
        return min;
    }

    /**
     * return BMI value.
     */
    public static String calculateBMI(double weight, double height) {
        double BMI = weight / (height * height);
        BMI = (double) Math.round(BMI * 10) / 10;
        if (BMI < 18.5) {
            return "Thiếu cân";
        }
        if (BMI >= 18.5 && BMI < 23) {
            return "Bình thường";
        }
        if (BMI >= 23 && BMI < 25) {
            return "Thừa cân";
        }
        return "Béo phì";
    }
}
