import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Person<T> {

    private String name;
    private int age;
    private String address;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Cst1.
     */
    public Person() {

    }

    /**
     * Cst2.
     */
    public Person(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    /**
     * Method.
     */
    public static <T> List<T> sortGeneric(List<T> arr) {
        Collections.sort(arr, new Comparator<T>() {
            @Override
            public int compare(T o1, T o2) {
                return String.valueOf(o1).compareTo(String.valueOf(o2));
            }
        });
        return arr;
    }

    @Override
    public String toString() {
        return name + "," + age + "," + address;
    }

    /**
     * Main.
     */
    public static void main(String[] args) {
        List<Person> arr = new ArrayList<>();
        Person p1 = new Person("Nguyen A", 22, "Vietnam");
        Person p2 = new Person("Nguyen A", 20, "Cao Bang");
        Person p3 = new Person("Le B", 20, "Tra Linh");
        arr.add(p1);
        arr.add(p2);
        arr.add(p3);
        arr = Person.sortGeneric(arr);
        for (int i = 0; i < arr.size(); i++) {
            System.out.println(arr.get(i));
        }
    }
}
 